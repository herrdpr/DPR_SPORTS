# DPR SPORTS ⚽

O aplicație web responsivă pentru gestionarea meciurilor și pronosticurilor sportive.

## Funcționalități
- Mod Light/Dark cu switch instant
- Autocompletare echipe
- Adăugare rapidă de meciuri
- Afișare carduri responsive

## Instalare
1. Deschide `index.html` în browser
2. Pentru GitHub Pages, urmează pașii:
   - Settings → Pages → Source: main branch
   - Accesează: https://username.github.io/DPR_SPORTS/

© 2025 Dragoș / CREATEO SRL